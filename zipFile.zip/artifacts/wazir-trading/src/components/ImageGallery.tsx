import React, { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/supabase';
import { ChevronLeft, ChevronRight, X, Maximize2, Download, Images, Camera, Map } from 'lucide-react';
import { isThirdPartyListing, ThirdPartyImageBadge } from '@/components/ThirdPartyImageBadge';
import { vehicleImageAlt } from '@/lib/vehicle-seo';

interface ImageGalleryProps {
  carId: string;
  refNumber: string;
  make: string;
  model: string;
  year?: number | null;
  variant?: string | null;
}

type ImgStatus = 'pending' | 'loaded' | 'error';

/**
 * Injects Cloudinary transformation params into a raw upload URL.
 * Handles both /image/upload/PUBLIC_ID and /image/upload/v123/PUBLIC_ID.
 * Skips URLs that already carry transformation segments.
 */
function withTransforms(url: string, transforms = 'f_auto,q_auto,w_800'): string {
  const marker = '/image/upload/';
  const idx = url.indexOf(marker);
  if (idx === -1) return url; // not a Cloudinary URL
  const after = url.slice(idx + marker.length);
  // Already has a transformation segment (contains a comma or known param)
  if (/^[a-z]_/.test(after)) return url;
  return url.slice(0, idx + marker.length) + transforms + '/' + after;
}

/** Returns true when a URL's filename ends in _map (e.g. ref-1_map.jpg) */
function isMapImage(url: string) {
  const path = url.split('?')[0];
  const filename = path.split('/').pop() ?? '';
  return /_map(\.[^.]+)?$/i.test(filename);
}

export default function ImageGallery({ carId, refNumber, make, model, year, variant }: ImageGalleryProps) {
  // Regular gallery images
  const [candidates, setCandidates] = useState<string[]>([]);
  const [statuses, setStatuses] = useState<ImgStatus[]>([]);
  const [fetching, setFetching] = useState(true);

  // Damage / inspection map image (separate)
  const [mapUrl, setMapUrl] = useState<string | null>(null);
  const [mapStatus, setMapStatus] = useState<ImgStatus>('pending');
  const [mapZoom, setMapZoom] = useState(false);

  // activeIndex is an index into the `valid` array (loaded images only)
  const [activeIdx, setActiveIdx] = useState(0);
  const [lightboxOpen, setLightboxOpen] = useState(false);
  const [lightboxIdx, setLightboxIdx] = useState(0);

  /* ── fetch candidate URLs ── */
  useEffect(() => {
    let cancelled = false;
    async function load() {
      setFetching(true);
      setCandidates([]);
      setStatuses([]);
      setActiveIdx(0);
      setMapUrl(null);
      setMapStatus('pending');

      try {
        const { data, error } = await supabase
          .from('car_images')
          .select('image_url, display_order, is_primary')
          .eq('car_id', carId)
          .order('display_order');

        if (cancelled) return;

        if (!error && data && data.length > 0) {
          const allUrls = data.map((r: { image_url: string }) => withTransforms(r.image_url));
          const regular = allUrls.filter((u: string) => !isMapImage(u));
          const maps    = allUrls.filter((u: string) => isMapImage(u));
          setCandidates(regular);
          setStatuses(regular.map(() => 'pending' as ImgStatus));
          if (maps.length > 0) {
            setMapUrl(maps[0]);
            setMapStatus('pending');
          } else {
            setMapStatus('error');
          }
        } else {
          // No images in car_images table — show placeholder
          setCandidates([]);
          setStatuses([]);
          setMapStatus('error');
        }
      } catch {
        if (!cancelled) { setCandidates([]); setStatuses([]); setMapStatus('error'); }
      } finally {
        if (!cancelled) setFetching(false);
      }
    }
    load();
    return () => { cancelled = true; };
  }, [carId, refNumber]);

  /* ── status updaters ── */
  const markLoaded = useCallback((i: number) => {
    setStatuses(prev => {
      const next = [...prev];
      next[i] = 'loaded';
      return next;
    });
  }, []);

  const markError = useCallback((i: number) => {
    setStatuses(prev => {
      const next = [...prev];
      next[i] = 'error';
      return next;
    });
  }, []);

  /* ── derived ── */
  const valid = candidates
    .map((url, i) => ({ url, origIdx: i }))
    .filter((_, i) => statuses[i] === 'loaded');

  const totalResolved = statuses.filter(s => s !== 'pending').length;
  const allResolved = totalResolved === candidates.length;
  const noImages = allResolved && valid.length === 0;

  const safeActive = valid.length > 0 ? Math.min(activeIdx, valid.length - 1) : 0;

  /* ── navigation ── */
  const prev = useCallback(() => setActiveIdx(i => (i - 1 + Math.max(valid.length, 1)) % Math.max(valid.length, 1)), [valid.length]);
  const next = useCallback(() => setActiveIdx(i => (i + 1) % Math.max(valid.length, 1)), [valid.length]);
  const lbPrev = useCallback(() => setLightboxIdx(i => (i - 1 + Math.max(valid.length, 1)) % Math.max(valid.length, 1)), [valid.length]);
  const lbNext = useCallback(() => setLightboxIdx(i => (i + 1) % Math.max(valid.length, 1)), [valid.length]);

  const openLightbox = (idx: number) => { setLightboxIdx(idx); setLightboxOpen(true); };

  /* ── keyboard (gallery lightbox) ── */
  useEffect(() => {
    if (!lightboxOpen) return;
    const h = (e: KeyboardEvent) => {
      if (e.key === 'ArrowLeft') lbPrev();
      if (e.key === 'ArrowRight') lbNext();
      if (e.key === 'Escape') setLightboxOpen(false);
    };
    window.addEventListener('keydown', h);
    return () => window.removeEventListener('keydown', h);
  }, [lightboxOpen, lbPrev, lbNext]);

  /* ── keyboard (map zoom) ── */
  useEffect(() => {
    if (!mapZoom) return;
    const h = (e: KeyboardEvent) => { if (e.key === 'Escape') setMapZoom(false); };
    window.addEventListener('keydown', h);
    return () => window.removeEventListener('keydown', h);
  }, [mapZoom]);

  /* ── download ── */
  const handleDownloadAll = () => {
    valid.forEach(({ url }, i) => {
      const a = document.createElement('a');
      a.href = url;
      a.download = `${make}-${model}-${refNumber}-${i + 1}.jpg`;
      a.target = '_blank';
      a.rel = 'noopener noreferrer';
      a.click();
    });
  };

  /* ── hidden preloader: renders all candidate <img> tags off-screen ── */
  const Preloader = (
    <div className="hidden" aria-hidden="true">
      {candidates.map((url, i) => (
        <img
          key={url + i}
          src={url}
          alt=""
          loading="eager"
          decoding="async"
          onLoad={() => markLoaded(i)}
          onError={() => markError(i)}
        />
      ))}
      {/* Preload map image too */}
      {mapUrl && mapStatus === 'pending' && (
        <img
          key={mapUrl}
          src={mapUrl}
          alt=""
          loading="lazy"
          decoding="async"
          onLoad={() => setMapStatus('loaded')}
          onError={() => setMapStatus('error')}
        />
      )}
    </div>
  );

  /* ── loading skeleton ── */
  if (fetching || (candidates.length > 0 && valid.length === 0 && !allResolved)) {
    return (
      <>
        {Preloader}
        <div className="space-y-3">
          <div className="aspect-[16/10] bg-gray-100 animate-pulse rounded-sm flex items-center justify-center">
            <Camera size={32} className="text-gray-300" />
          </div>
          <div className="flex gap-2">
            {[1, 2, 3, 4].map(n => (
              <div key={n} className="w-16 h-12 bg-gray-100 animate-pulse rounded-sm flex-shrink-0" />
            ))}
          </div>
        </div>
      </>
    );
  }

  /* ── no images ── */
  if (noImages || candidates.length === 0) {
    return (
      <>
        {Preloader}
        <div className="aspect-[16/10] bg-gray-50 border border-gray-200 flex flex-col items-center justify-center rounded-sm gap-3">
          <Camera size={40} className="text-gray-200" />
          <div className="text-center">
            <p className="font-serif text-lg text-gray-300 font-medium">{make} {model}</p>
            <p className="text-xs text-gray-300 mt-1">Photos coming soon</p>
          </div>
        </div>
      </>
    );
  }

  const activeImage = valid[safeActive];
  const isThirdParty = isThirdPartyListing(refNumber);
  const seoCar = { ref_number: refNumber, make, model, year, variant };

  return (
    <>
      {Preloader}
      <div className="space-y-3">

        {/* ── Main image ── */}
        <div className="relative w-full h-[300px] sm:h-[380px] lg:h-[500px] overflow-hidden rounded-sm group flex items-center justify-center">

          {/* Photo count badge */}
          <div className="absolute top-3 left-3 z-10 bg-black/70 text-white text-xs font-semibold px-2.5 py-1 rounded-sm flex items-center gap-1.5 backdrop-blur-sm">
            <Images size={12} />
            {valid.length} {valid.length === 1 ? 'Photo' : 'Photos'}
          </div>

          {/* Main image */}
          {activeImage && (
            <img
              key={activeImage.url}
              src={activeImage.url}
              alt={vehicleImageAlt(seoCar, safeActive, `vehicle photo of ${valid.length}`)}
              className="block w-full h-full object-contain transition-opacity duration-300"
              width="800"
              height="600"
              loading="eager"
              fetchPriority="high"
              decoding="async"
            />
          )}
          {isThirdParty && <ThirdPartyImageBadge className="top-3 right-3" />}

          {/* Prev arrow */}
          {valid.length > 1 && (
            <>
              <button
                onClick={prev}
                className="absolute left-3 top-1/2 -translate-y-1/2 z-10 w-10 h-10 bg-black/60 hover:bg-black/85 text-white flex items-center justify-center rounded-sm transition-all opacity-0 group-hover:opacity-100 backdrop-blur-sm"
                aria-label="Previous image"
              >
                <ChevronLeft size={22} />
              </button>
              <button
                onClick={next}
                className="absolute right-3 top-1/2 -translate-y-1/2 z-10 w-10 h-10 bg-black/60 hover:bg-black/85 text-white flex items-center justify-center rounded-sm transition-all opacity-0 group-hover:opacity-100 backdrop-blur-sm"
                aria-label="Next image"
              >
                <ChevronRight size={22} />
              </button>
            </>
          )}

          {/* View Fullscreen */}
          <button
            onClick={() => openLightbox(safeActive)}
            className="absolute bottom-3 right-3 z-10 bg-black/60 hover:bg-black/85 text-white text-xs font-medium px-3 py-1.5 flex items-center gap-1.5 rounded-sm backdrop-blur-sm transition-all opacity-0 group-hover:opacity-100"
          >
            <Maximize2 size={12} /> View Fullscreen
          </button>

          {/* Counter pill */}
          {valid.length > 1 && (
            <div className="absolute bottom-3 left-3 z-10 bg-black/60 text-white text-xs font-medium px-2.5 py-1 rounded-sm backdrop-blur-sm opacity-0 group-hover:opacity-100 transition-all">
              {safeActive + 1} / {valid.length}
            </div>
          )}

          {/* Dot indicators (≤ 15 images) */}
          {valid.length > 1 && valid.length <= 15 && (
            <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex gap-1.5 z-10">
              {valid.map((_, idx) => (
                <button
                  key={idx}
                  onClick={() => setActiveIdx(idx)}
                  aria-label={`Go to photo ${idx + 1}`}
                  className={`w-1.5 h-1.5 rounded-full transition-all ${idx === safeActive ? 'bg-white scale-125' : 'bg-white/50 hover:bg-white/80'}`}
                />
              ))}
            </div>
          )}
        </div>

        {/* ── Thumbnail strip ── */}
        {valid.length > 1 && (
          <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-thin scroll-smooth">
            {valid.map(({ url }, idx) => (
              <button
                key={url}
                onClick={() => setActiveIdx(idx)}
                aria-label={`View photo ${idx + 1}`}
                className={`flex-shrink-0 w-16 h-12 relative overflow-hidden rounded-sm border-2 transition-all duration-150 ${
                  idx === safeActive
                    ? 'border-[#C8102E] opacity-100 shadow-sm'
                    : 'border-transparent opacity-55 hover:opacity-90 hover:border-gray-300'
                }`}
              >
                <img
                  src={url}
                   alt={vehicleImageAlt(seoCar, idx, 'thumbnail')}
                  className="w-full h-full object-contain"
                   width="64"
                   height="48"
                   loading="lazy"
                   decoding="async"
                />
              </button>
            ))}
          </div>
        )}

        {/* ── Download All ── */}
        {valid.length > 0 && (
          <div className="flex justify-end">
            <button
              onClick={handleDownloadAll}
              className="text-xs text-gray-400 hover:text-[#C8102E] flex items-center gap-1.5 transition-colors"
            >
              <Download size={13} /> Download All Photos ({valid.length})
            </button>
          </div>
        )}

        {/* ── Auction Inspection Map ── */}
        {mapStatus === 'loaded' && mapUrl && (
          <div className="border border-amber-200 rounded-sm overflow-hidden bg-amber-50/40">
            {/* Header */}
            <div className="flex items-center justify-between px-4 py-2.5 bg-amber-50 border-b border-amber-200">
              <div className="flex items-center gap-2">
                <Map size={14} className="text-amber-600" />
                <span className="text-xs font-bold text-amber-800 tracking-wide uppercase">
                  Auction Inspection Map
                </span>
              </div>
              <button
                onClick={() => setMapZoom(true)}
                className="flex items-center gap-1.5 text-xs font-semibold text-amber-700 hover:text-amber-900 transition-colors px-2 py-1 rounded hover:bg-amber-100"
              >
                <Maximize2 size={12} /> Zoom
              </button>
            </div>

            {/* Map image — click anywhere to zoom */}
            <button
              className="block w-full cursor-zoom-in group"
              onClick={() => setMapZoom(true)}
              aria-label="View inspection map fullscreen"
            >
              <img
                src={mapUrl}
                alt={`${make} ${model} auction inspection damage map`}
                className="w-full max-h-[480px] object-contain bg-white transition-opacity group-hover:opacity-90"
              width="800"
              height="600"
              loading="lazy"
              decoding="async"
              />
            </button>

            <p className="text-[10px] text-amber-600/70 text-center py-1.5">
              Click image to zoom · Japan auction inspection report
            </p>
          </div>
        )}
      </div>

      {/* ══ Gallery Lightbox ══ */}
      {lightboxOpen && valid.length > 0 && (
        <div
          className="fixed inset-0 z-50 bg-black/96 flex items-center justify-center"
          onClick={() => setLightboxOpen(false)}
        >
          {/* Close */}
          <button
            onClick={() => setLightboxOpen(false)}
            className="absolute top-4 right-4 z-50 w-10 h-10 bg-white/10 hover:bg-white/20 text-white flex items-center justify-center rounded-full transition-colors"
            aria-label="Close"
          >
            <X size={20} />
          </button>

          {/* Counter */}
          <div className="absolute top-4 left-4 z-50 text-white/70 text-sm font-medium">
            {lightboxIdx + 1} / {valid.length}
          </div>

          {/* Car label */}
          <div className="absolute top-4 left-1/2 -translate-x-1/2 z-50 text-white/50 text-xs font-medium tracking-wide hidden sm:block">
            {make} {model} · REF #{refNumber}
          </div>

          {/* Main lightbox image */}
          <div
            className="relative max-w-5xl w-full h-[70vh] sm:h-[80vh] px-16"
            onClick={e => e.stopPropagation()}
          >
            <img
              key={valid[lightboxIdx]?.url}
              src={valid[lightboxIdx]?.url}
              alt={`${make} ${model} — ${lightboxIdx + 1}`}
              className="w-full h-full object-contain mx-auto block"
              width="1200"
              height="900"
              loading="eager"
              decoding="async"
            />
            {isThirdParty && <ThirdPartyImageBadge className="top-4 left-20" />}
          </div>

          {/* Lightbox arrows */}
          {valid.length > 1 && (
            <>
              <button
                onClick={e => { e.stopPropagation(); lbPrev(); }}
                className="absolute left-4 top-1/2 -translate-y-1/2 w-12 h-12 bg-white/10 hover:bg-white/25 text-white flex items-center justify-center rounded-full transition-colors"
                aria-label="Previous"
              >
                <ChevronLeft size={26} />
              </button>
              <button
                onClick={e => { e.stopPropagation(); lbNext(); }}
                className="absolute right-4 top-1/2 -translate-y-1/2 w-12 h-12 bg-white/10 hover:bg-white/25 text-white flex items-center justify-center rounded-full transition-colors"
                aria-label="Next"
              >
                <ChevronRight size={26} />
              </button>
            </>
          )}

          {/* Lightbox thumbnail strip */}
          <div className="absolute bottom-4 left-0 right-0 flex justify-center gap-2 overflow-x-auto px-4 pb-1">
            {valid.map(({ url }, idx) => (
              <button
                key={url}
                onClick={e => { e.stopPropagation(); setLightboxIdx(idx); }}
                aria-label={`View photo ${idx + 1}`}
                className={`flex-shrink-0 w-14 h-10 overflow-hidden rounded-sm border-2 transition-all ${
                  idx === lightboxIdx ? 'border-[#C8102E] opacity-100' : 'border-transparent opacity-45 hover:opacity-80'
                }`}
              >
                 <img src={url} alt="" className="w-full h-full object-contain" width="56" height="40" loading="lazy" decoding="async" />
              </button>
            ))}
          </div>
        </div>
      )}

      {/* ══ Inspection Map Zoom Lightbox ══ */}
      {mapZoom && mapUrl && (
        <div
          className="fixed inset-0 z-50 bg-black/96 flex items-center justify-center p-4"
          onClick={() => setMapZoom(false)}
        >
          <button
            onClick={() => setMapZoom(false)}
            className="absolute top-4 right-4 z-50 w-10 h-10 bg-white/10 hover:bg-white/20 text-white flex items-center justify-center rounded-full transition-colors"
            aria-label="Close"
          >
            <X size={20} />
          </button>

          <div className="absolute top-4 left-1/2 -translate-x-1/2 z-50 flex items-center gap-2 text-amber-300 text-xs font-semibold tracking-wide">
            <Map size={13} /> Auction Inspection Map — {make} {model}
          </div>

          <div
            className="relative max-w-4xl w-full max-h-[90vh] overflow-auto"
            onClick={e => e.stopPropagation()}
          >
            <img
              src={mapUrl}
              alt={`${make} ${model} auction inspection map`}
              className="w-full object-contain mx-auto block rounded-sm"
              width="1200"
              height="900"
              loading="eager"
              decoding="async"
            />
          </div>
        </div>
      )}
    </>
  );
}
